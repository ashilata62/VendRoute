import { Router } from 'express';
import { getMachines, createMachine, updateMachineStock } from '../controllers/machineController.js';
import { optionalAuth } from '../middlewares/authMiddleware.js';
import { validateRequest } from '../middlewares/validateMiddleware.js';
import { createMachineSchema, updateMachineStockSchema } from '../validators/machineValidator.js';

const router = Router();

// Testing mode — optionalAuth on all routes
router.get('/', optionalAuth, getMachines);
router.post('/', optionalAuth, validateRequest(createMachineSchema), createMachine);
router.patch('/:id/stock', optionalAuth, validateRequest(updateMachineStockSchema), updateMachineStock);

export default router;
