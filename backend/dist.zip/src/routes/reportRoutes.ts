import { Router } from 'express';
import { getDashboardStats } from '../controllers/reportController.js';
import { optionalAuth } from '../middlewares/authMiddleware.js';

const router = Router();

router.get('/dashboard', optionalAuth, getDashboardStats);

export default router;
