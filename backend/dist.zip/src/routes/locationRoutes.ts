import { Router } from 'express';
import { getLocations, getLocationById, createLocation, updateLocation, deleteLocation } from '../controllers/locationController.js';
import { optionalAuth } from '../middlewares/authMiddleware.js';
import { validateRequest } from '../middlewares/validateMiddleware.js';
import { createLocationSchema } from '../validators/locationValidator.js';

const router = Router();

// Testing mode — optionalAuth on all routes
router.get('/', optionalAuth, getLocations);
router.get('/:id', optionalAuth, getLocationById);
router.post('/', optionalAuth, validateRequest(createLocationSchema), createLocation);
router.put('/:id', optionalAuth, updateLocation);
router.delete('/:id', optionalAuth, deleteLocation);

export default router;
