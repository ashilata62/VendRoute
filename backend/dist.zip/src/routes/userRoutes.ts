import { Router } from 'express';
import { getUsers, getUserById, createUser, deleteUser, updateUser } from '../controllers/userController.js';
import { optionalAuth } from '../middlewares/authMiddleware.js';

const router = Router();

router.get('/', optionalAuth, getUsers);
router.post('/', optionalAuth, createUser);
router.get('/:id', optionalAuth, getUserById);
router.put('/:id', optionalAuth, updateUser);
router.delete('/:id', optionalAuth, deleteUser);

export default router;
