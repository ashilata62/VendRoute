import { Router } from 'express';
import { getRoutes, getRouteById, createRoute, updateStopStatus, deleteRoute, updateRoute } from '../controllers/routeController.js';
import { optionalAuth } from '../middlewares/authMiddleware.js';
import { validateRequest } from '../middlewares/validateMiddleware.js';
import { createRouteSchema, updateStopStatusSchema } from '../validators/routeValidator.js';

const router = Router();

// Testing mode — optionalAuth on all routes
router.get('/', optionalAuth, getRoutes);
router.get('/:id', optionalAuth, getRouteById);
router.post('/', optionalAuth, validateRequest(createRouteSchema), createRoute);
router.put('/:id', optionalAuth, updateRoute);
router.patch('/stops/:stopId', optionalAuth, validateRequest(updateStopStatusSchema), updateStopStatus);
router.delete('/:id', optionalAuth, deleteRoute);

export default router;
