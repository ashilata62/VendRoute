import { Router } from 'express';
import { getCustomers, getCustomerById, createCustomer, updateCustomer, deleteCustomer } from '../controllers/customerController.js';
import { optionalAuth } from '../middlewares/authMiddleware.js';
import { validateRequest } from '../middlewares/validateMiddleware.js';
import { createCustomerSchema, updateCustomerSchema } from '../validators/customerValidator.js';

const router = Router();

// All routes use optionalAuth — testing mode (mock login active)
// When real login is enabled, switch optionalAuth → authenticateJWT for write routes
router.get('/', optionalAuth, getCustomers);
router.get('/:id', optionalAuth, getCustomerById);
router.post('/', optionalAuth, validateRequest(createCustomerSchema), createCustomer);
router.put('/:id', optionalAuth, validateRequest(updateCustomerSchema), updateCustomer);
router.delete('/:id', optionalAuth, deleteCustomer);

export default router;
