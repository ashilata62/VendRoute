import { Router } from 'express';
import { getVehicles, getVehicleById, createVehicle, updateVehicle, deleteVehicle } from '../controllers/vehicleController.js';
import { optionalAuth } from '../middlewares/authMiddleware.js';

const router = Router();

router.get('/', optionalAuth, getVehicles);
router.get('/:id', optionalAuth, getVehicleById);
router.post('/', optionalAuth, createVehicle);
router.put('/:id', optionalAuth, updateVehicle);
router.delete('/:id', optionalAuth, deleteVehicle);

export default router;
