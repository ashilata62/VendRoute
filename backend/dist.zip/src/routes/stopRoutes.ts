import { Router } from 'express';
import { getStops, checkInStop } from '../controllers/stopController.js';
import { optionalAuth } from '../middlewares/authMiddleware.js';

const router = Router();

router.get('/', optionalAuth, getStops);
router.put('/:id/checkin', optionalAuth, checkInStop);

export default router;
